﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace PR15_16
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите количество рабочих N=");
            int N = int.Parse(Console.ReadLine());
            clsWORKER[] worker = new clsWORKER[N];
            for (int i = 0; i < N; i++)
            {
                worker[i] = new clsWORKER();
                worker[i].FIO = Console.ReadLine();
                worker[i].POST = Console.ReadLine();
                worker[i].DATERECEIPTS = int.Parse(Console.ReadLine());
            }
            foreach (clsWORKER cls in worker)
            {
                Console.WriteLine(cls.PrintInfo());
            }
            StreamWriter  sw = new StreamWriter
            StreamWriter (@"results.txt")
            Console.ReadKey();
        }
    }
}
