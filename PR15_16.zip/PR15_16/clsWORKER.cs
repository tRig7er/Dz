﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PR15_16
{
    class clsWORKER
    {
        private string fio;
        private string post;
        private int datereceipts;
        public string FIO
        {
            get { return fio; }
            set { fio = value; }
        }
        public string POST
        {
            get { return post; }
            set { post = value; }
        }
        public int DATERECEIPTS
        {
            get { return datereceipts; }
            set { datereceipts = value; }
        }
        public clsWORKER()
        {
            post = "it";
        }
        public clsWORKER(int year, string f, string p)
        {
            fio = f;
            datereceipts = year;
            post = p;
        }
        public string PrintInfo()
        {
            return $"Рабочий: {fio} Дата поступления {datereceipts} " +
                $"Должность: {post}";
        }
    }
}
