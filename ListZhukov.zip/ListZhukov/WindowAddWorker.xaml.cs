﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using ListZhukov.Classes;

namespace ListZhukov
{
    /// <summary>
    /// Логика взаимодействия для WindowAddWorker.xaml
    /// </summary>
    public partial class WindowAddWorker : Window
    {
        public WindowAddWorker()
        {
            InitializeComponent();
        }


        private void BtnAddWorker_Click(object sender, RoutedEventArgs e)
        {
            Worker workers = new Worker()
            {
                NameWorker = TxbName.Text,
                PostWorker = TxbPost.Text,
                DateWorker = int.Parse(TxbDate.Text)
            };
            ConnectHelper.workers.Add(workers);
            this.Close();
        }
    }
}
