﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ListZhukov.Classes
{
    class Worker
    {//поля
        string nameWorker;
        string postWorker;
        int dateWorker;

        //свойства
        public string NameWorker
        {
            get { return NameWorker; }
            set { NameWorker = value; }
        }
        public string PostWorker
        {
            get { return PostWorker; }
            set { PostWorker = value; }
        }
        public int DateWorker
        {
            get { return DateWorker; }
            set { DateWorker = value; }
        }
       
        //конструкторы
        public Worker()
        {
            NameWorker = "";
            PostWorker = "";
            DateWorker = 0;
        }
        public Worker(string name, string post,int date)
        {
            NameWorker = name;
            PostWorker = post;
            DateWorker = date;
        }
    }  
}
