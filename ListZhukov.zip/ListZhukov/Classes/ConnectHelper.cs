﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ListZhukov.Classes
{
    class ConnectHelper
    {
        public static List<Worker> workers = new List<Worker>();
    }
}
