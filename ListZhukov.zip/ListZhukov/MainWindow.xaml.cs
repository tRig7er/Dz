﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ListZhukov.Classes;

namespace ListZhukov
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        List<Worker> workers = new List<Worker>();
        public MainWindow()
        {
            InitializeComponent();
            ConnectHelper.workers.Add(new Worker("Шинкаренко Е.А", "Программист",2017));
            ConnectHelper.workers.Add(new Worker("Мелега А.В", "Программист", 2018));

        }

        private void BtnPrint_Click(object sender, RoutedEventArgs e)
        {
            DtgListWorker.ItemsSource = ConnectHelper.workers.ToList();
            DtgListWorker.SelectedIndex = -1;
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            WindowAddWorker windowAdd = new WindowAddWorker();
            windowAdd.ShowDialog();
        
        }

        private void BtnClear_Click(object sender, RoutedEventArgs e)
        {
            DtgListWorker.ItemsSource = null;
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {

        }

        private void RbUp_Checked(object sender, RoutedEventArgs e)
        {
            DtgListWorker.ItemsSource = ConnectHelper.workers.OrderBy(x => x.NameWorker).ToList();
        }

        private void RbDown_Checked(object sender, RoutedEventArgs e)
        {
            DtgListWorker.ItemsSource = ConnectHelper.workers.OrderByDescending(x => x.NameWorker).ToList();
        }

        private void CmbFiltr_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}
